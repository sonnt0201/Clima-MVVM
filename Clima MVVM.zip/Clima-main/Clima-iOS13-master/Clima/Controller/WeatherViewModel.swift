//
//  WeatherViewModel.swift
//  Clima
//
//  Created by Son Le on 04/07/2022.
//  Copyright © 2022 App Brewery. All rights reserved.
//

import Foundation
import CoreLocation


protocol WeatherViewModelCallback: AnyObject {
    func updateWeather(_ weather: WeatherModel)
}

class WeatherViewModel {
    
    private var locationManager = CLLocationManager()
    private var weatherManager = WeatherManager()
    
    weak var callback: WeatherViewModelCallback?
    
    func requestLocation() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
    }
    
    func search(term: String) {
        weatherManager.fetchWeather(cityName: term)
    }
    
    func onTapLocationButton() {
        weatherManager.compare(lat: lat, lng: lng)
        locationManager.requestLocation()
    }
    
    func onTapDetail() {
        
    }
}

extension WeatherViewModel: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            locationManager.stopUpdatingLocation()
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            weatherManager.fetchWeather (latitude: lat, longitude: lon)
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
    }
}

extension WeatherViewModel: WeatherManagerDelegate {
    func didFailWithError(error: Error) {
        
    }
    
    func didUpdateWeather(weatherManager: WeatherManager, weather: WeatherModel) {
        DispatchQueue.main.async {
            self.callback?.updateWeather(weather)
        }
        
    }
}
