//
//  ViewController.swift
//  Clima
//
//  Created by Angela Yu on 01/09/2019.
//  Copyright © 2019 App Brewery. All rights reserved.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController {

    @IBOutlet weak var conditionImageView: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    
    @IBOutlet weak var searchTextField: UITextField!
    
    private let viewModel = WeatherViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchTextField.delegate = self
        cityLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onTapDetail)))
        viewModel.callback = self
    }

    @objc private func onTapDetail() {
        viewModel.onTapDetail()
    }
    
    @IBAction func searchPressed(_ sender: UIButton) {
        searchTextField.endEditing(true)
        search(term: searchTextField.text!)
    }
    
    @IBAction func locationButtonPressed(_ sender: UIButton) {
        viewModel.onTapLocationButton()
    }
    
    private func search(term: String) {
        viewModel.search(term: term)
    }
}

extension WeatherViewController: UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        searchTextField.endEditing(true)
        print(searchTextField.text!)
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        guard let city = searchTextField.text else { return }
        search(term: city)
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            return true
        }else{
            textField.placeholder = "Type something"
            return false
        }
    }
}

extension WeatherViewController: WeatherViewModelCallback {
    func updateWeather(_ weather: WeatherModel) {
        self.temperatureLabel.text = weather.temparatureString
        self.conditionImageView.image = UIImage(systemName: weather.conditionName)
        self.cityLabel.text = weather.cityName
    }
}
